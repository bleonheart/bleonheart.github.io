
<div class="card-grid">
  <a href="./armors/" class="card">
    <h3>Advanced Armors</h3>
    <p>Adds standard armors with equippable protection stats, overlays, optional training requirements, and mod support. Features: damage resistance, movement/jump bonuses, fall protection, footstep sounds, armor mod installation/removal, and admin toggletraining command.</p>
  </a>
  <a href="./fantasyarmors/" class="card">
    <h3>Advanced Armors - Fantasy Edition</h3>
    <p>Adds fantasy-themed armors with equippable protection stats, overlays, optional training requirements, and mod support. Features: damage resistance, movement/jump bonuses, fall protection, footstep sounds, armor mod installation/removal, and admin toggletraining command.</p>
  </a>
  <a href="./banking/" class="card">
    <h3>Advanced Banking</h3>
    <p>Comprehensive banking infrastructure featuring multi-tier account management (free, premium, VIP), physical ATM network with model customization, secure check writing and redemption system, item storage vaults with tiered capacity, automated interest accrual with configurable rates and limits, paycheck integration with direct deposit options, administrative oversight tools for account monitoring and management, faction-based transaction controls, and robust permission system for member access management across joint accounts</p>
  </a>
  <a href="./anim/" class="card">
    <h3>Advanced Bone Manipulation Animation</h3>
    <p>Advanced bone manipulation system that provides realistic roleplay animations through precise skeletal control. Utilizes ValveBiped bone structure to create natural-looking poses including surrender (hands-up), military salutes, crossed arms, attention stances, typing posture, and various gestures. Features automatic interruption on movement, jumping, weapon switching, or vehicle entry to maintain gameplay flow. Integrates with lia.playerinteract for seamless context menu access, supports timed animations with auto-deactivation, and includes comprehensive cleanup systems for map changes and character respawns. Server-authoritative with networked synchronization ensures all players see consistent animations across the multiplayer environment.</p>
  </a>
  <a href="./bonemerge/" class="card">
    <h3>Advanced Bonemerge Clothing</h3>
    <p>Comprehensive bonemerge-based clothing system that allows players to equip and customize outfits with multiple clothing slots. Features dynamic model merging, slot-based inventory management, gender-specific clothing, VIP items, plastic surgery, and a complete vendor system for purchasing and managing clothing items including hats, shirts, pants, shoes, accessories, and full outfits.</p>
  </a>
  <a href="./carspawner/" class="card">
    <h3>Advanced Car Spawner</h3>
    <p>Comprehensive vehicle spawning system that provides players with an interactive GUI menu to browse, purchase, and spawn various vehicles. Features include customizable car registration system, physical car crate entities, intelligent spawn positioning with collision detection, currency integration, and support for both LVS and custom vehicle classes. The system includes server-side vehicle management, client-side interface with scrollable car listings, and automatic vehicle ownership assignment through CPPI.</p>
  </a>
  <a href="./corpselooting/" class="card">
    <h3>Advanced Corpse Looting</h3>
    <p>Comprehensive corpse management and looting system that creates realistic player corpses upon death with full inventory and money transfer. Features include: automatic corpse creation with player appearance preservation, dual inventory interface for seamless item transfer between player and corpse, bidirectional money deposit/withdrawal system with real-time synchronization, distance-based looting mechanics with anti-spam protection, multi-user corpse access with shared state management, automatic cleanup of corpse inventories on removal, and visual/audio feedback for all transactions. The system handles equipped items by unequipping them before transfer and supports both modern inventory instances and legacy item systems.</p>
  </a>
  <a href="./crafting/" class="card">
    <h3>Advanced Crafting</h3>
    <p>Comprehensive crafting system featuring multiple crafting stations (forge, workbench), recipe-based crafting with time-based progress bars, attribute requirements and skill progression, tool dependencies, faction restrictions, knowledge system with recipe books, dynamic UI with progress tracking and cancellation, item consumption and output with randomized quantities, and automatic entity registration for crafting stations</p>
  </a>
  <a href="./identifications/" class="card">
    <h3>Advanced Identification & Character Registry</h3>
    <p>Comprehensive identification system featuring customizable character profiles with physical attributes (age, sex, ethnicity, weight, eye/hair color, blood type), multiple regional ID card designs (California, German, Florida, New York, Southside, Yorkshire), character recognition mechanics, and interactive ID viewing/requesting functionality. Includes gender-based model filtering, persistent character data storage, and administrative ID management tools for immersive roleplaying scenarios.</p>
  </a>
  <a href="./policesuite/" class="card">
    <h3>Advanced Police Suite</h3>
    <p>Complete law enforcement management system featuring 23-tier police rank hierarchy with progressive salaries and equipment kits, comprehensive criminal code with detailed offenses and sentencing guidelines, advanced police computer database with real-time criminal records, warrant management, and serial number tracking, specialized police equipment including tasers, nightsticks, and finebooks, dynamic jail cell management system with map-specific configurations, police locker and NPC integration, dispatcher system for citizen help requests, internal affairs oversight, and extensive administrative privileges for police faction management.</p>
  </a>
  <a href="./radio/" class="card">
    <h3>Advanced Radio Communication</h3>
    <p>Comprehensive radio communication framework featuring handheld radios and stationary broadcast units with frequency tuning, encrypted faction channels, preset stations, range-based transmission, static noise effects, and Star Wars RP comlink compatibility. Supports both item-based and entity-based radio devices with real-time voice transmission, channel management, and secure communications for different factions.</p>
  </a>
  <a href="./airraids/" class="card">
    <h3>Air Raid Event System</h3>
    <p>Random and staff-triggered bombing raids with configurable map zones and post-raid looting.</p>
  </a>
  <a href="./blackmarket/" class="card">
    <h3>Black Market Trading</h3>
    <p>A comprehensive underground trading system featuring an elusive NPC black market dealer who sells illegal weapons, contraband items, and restricted goods. The system includes dynamic inventory management with limited stock quantities, automatic restock timers that replenish supplies over time, configurable pricing structures, secret location mechanics requiring players to discover the hidden shop, waypoint/package delivery systems for illicit transactions, and administrative tools for managing the black market economy. Perfect for servers seeking enhanced criminal roleplay opportunities with an immersive underground economy.</p>
  </a>
  <a href="./cameras/" class="card">
    <h3>CCTV Surveillance</h3>
    <p>Complete CCTV surveillance network system featuring physical camera entities (lia_cam) that can be deployed and linked to monitor mainframes (lia_cctv). Players can access live camera feeds through monitor interfaces with faction-restricted permissions, or remotely using Personal Access Devices (PAD). The system supports multiple mainframes, named camera networks, real-time feed streaming, and provides comprehensive surveillance capabilities for roleplay scenarios with proper access control and authentication mechanisms.</p>
  </a>
  <a href="./leveling/" class="card">
    <h3>Character Progression</h3>
    <p>A comprehensive character progression system featuring experience points, level advancement, and a skill tree system. Players earn XP through various activities, level up to gain skill points, and invest in three distinct skill paths: Endurance (increases maximum health by 25), Combat Training (boosts weapon damage by 15%), and Engineering (enhances tool effectiveness by 15% and repair speed by 30%). The system includes skill dependencies requiring certain levels, full F1 menu integration for skill management, network synchronization for multiplayer functionality, and administrative tools for XP/skill adjustments. Engineering skill requires Endurance tier 1 as a prerequisite, creating meaningful progression choices.</p>
  </a>
  <a href="./chess/" class="card">
    <h3>Chess & Draughts Gaming</h3>
    <p>Comprehensive chess and draughts (checkers) gaming system featuring fully interactive board games with real-time multiplayer support, Elo rating system with K-factor customization, persistent game statistics tracking, wagering mechanics for competitive play, global leaderboards, draw/resign functionality, pawn promotion selection, and seamless integration with the Lilia framework</p>
  </a>
  <a href="./helpnpc/" class="card">
    <h3>City Guide NPC</h3>
    <p>Implements a comprehensive City Guide NPC system that provides new player orientation and navigation assistance. Features include interactive dialog trees with multiple conversation paths, automatic waypoint marking for important city landmarks (Downtown, Central Park), detailed location information, and contextual guidance about the city</p>
  </a>
  <a href="./ranking/" class="card">
    <h3>Class Ranking</h3>
    <p>Comprehensive hierarchical ranking system that manages player positions within classes. Provides promotion, demotion, hiring, and kicking functionality with tier-based permissions. Automatically assigns rank-specific weapons, clearance levels, and models. Includes administrative commands and privilege-based access control for class management.</p>
  </a>
  <a href="./achievements/" class="card">
    <h3>Comprehensive Achievement</h3>
    <p>Full-featured achievement system with real-time progress tracking, visual progress bars, and administrative oversight. Supports multiple achievement types: kill-based tracking (zombies, players, NPCs with specific entity targeting), item collection milestones, playtime rewards, death tracking, and complex multi-objective challenges with nested progress tracking. Features persistent character-based storage via Lilia</p>
  </a>
  <a href="./drugs/" class="card">
    <h3>Comprehensive Drug</h3>
    <p>Complete drug economy and gameplay system featuring cultivation (weed planting with growth phases), processing (drug processor machines), consumption with various effects (speed boost, damage reduction, stamina regeneration, melee speed, needs decay reduction, ragdoll recovery), overdose mechanics with configurable chances, addiction system, visual effects HUD, and administrative controls. Includes 6 drug types: Cocaine, Heroin, Weed, Meth, LSD, and MDMA, each with unique properties and processing requirements.</p>
  </a>
  <a href="./injuries/" class="card">
    <h3>Comprehensive Injury</h3>
    <p>A comprehensive injury management system featuring multiple injury types including broken legs, bleeding wounds, head concussions, and pain effects. Each injury has unique side effects, healing requirements, and medical treatment options. Includes medical items, treatment minigames, and persistent injury tracking across player sessions.</p>
  </a>
  <a href="./medals/" class="card">
    <h3>Comprehensive Medal</h3>
    <p>A comprehensive medal award and display system featuring multiple themed medal packs (1942 RP, US Military branches, Police departments, Star Wars RP), persistent character-based medal storage with rarity tiers (Common, Uncommon, Rare, Exceptionally Rare), staff permissions for medal management, wearable medal slots (up to 5 medals), character profile integration, and admin controls for giving/taking medals with full network synchronization</p>
  </a>
  <a href="./gathering/" class="card">
    <h3>Comprehensive Resource Gathering & Crafting</h3>
    <p>A complete resource gathering system featuring tree harvesting (spruce wood, sticks, tree sap, logs, wood planks) with axe-based chopping mechanics, ore mining from rocks (iron, gold, silver ore, coal, stone) for smelting into ingots, an interactive fishing system requiring poles and bait that yields various fish types (lake trout, bass, catfish, perch) plus junk items (old boots, trash), comprehensive crafting materials processing (raw resources into refined materials like iron ingots, wood planks, and weapons such as iron swords), and full stackable inventory management with configurable max quantities for all gathered items.</p>
  </a>
  <a href="./computers/" class="card">
    <h3>Computer</h3>
    <p>Comprehensive computer system featuring interactive computer entities with customizable desktop interfaces, built-in applications including Notes and Fakebook social media, web browser functionality, and game integration. Provides network communication for computer interactions, popup management, and extensible app panel system for creating custom computer applications within the Lilia RP framework.</p>
  </a>
  <a href="./disks/" class="card">
    <h3>Data Storage</h3>
    <p>Comprehensive data storage system featuring portable memory disks (64C-1024C capacity) with read/write functionality, password protection, and terminal/decoder integration. Includes physical disk entities, inventory items, and interactive terminals for data manipulation and storage.</p>
  </a>
  <a href="./dt_scrambler/" class="card">
    <h3>Death Trooper Voice Scrambler</h3>
    <p>Advanced voice communication scrambling system for the Death Trooper faction. Provides secure encrypted voice channels that prevent unauthorized players from hearing DT communications. When enabled, non-Death Trooper listeners cannot hear the voice chat and instead hear randomized static/scrambling sound effects. Authorized Death Trooper members and uplinked players can communicate normally while maintaining operational security. Features real-time voice filtering, multiple scrambling sound effects, and visual voice indicators showing scrambler status.</p>
  </a>
  <a href="./delivery/" class="card">
    <h3>Delivery Job</h3>
    <p>A comprehensive delivery job system that provides players with parcel delivery missions. Features include a dedicated Delivery faction, randomly generated delivery locations across different maps, time-sensitive deliveries with visual indicators, delivery van spawning with custom bodygroups, crate pickup and drop-off mechanics, distance-based interaction prompts, monetary rewards for completed deliveries, visual waypoint markers showing delivery destinations, cooldown system between deliveries, and proper cleanup of delivery entities on disconnect or faction change. The system encourages map exploration and provides an engaging roleplaying experience for players seeking delivery work.</p>
  </a>
  <a href="./events/" class="card">
    <h3>Dynamic Event</h3>
    <p>Comprehensive dynamic event system that creates map-specific NPC encounters with automatic scheduling, configurable spawn positions with radius-based randomization, player count requirements, intelligent spawn validation using hull traces, staff commands for manual event control, and real-time player notifications. Supports multiple concurrent events per map with customizable NPCs, positions, and messages.</p>
  </a>
  <a href="./extraction/" class="card">
    <h3>Extraction Flare</h3>
    <p>Extraction flare system that allows players to signal extraction points by throwing throwable flares. Includes configurable extraction positions per map, flare grenade items, visual effects, and network messaging for extraction coordination. Provides raid-style extraction mechanics with countdown timers and escape zone functionality.</p>
  </a>
  <a href="./factionwar/" class="card">
    <h3>Faction War</h3>
    <p>Standalone faction relation, war operation, and Derma manager system.</p>
  </a>
  <a href="./fence/" class="card">
    <h3>Fence - Black Market Dealer</h3>
    <p>A comprehensive fence NPC system that provides underground black market services. Features include: Purchase stolen items and contraband from players at fair market values, Dynamic pricing based on item reward values and rarity, Full integration with the robbery system for all stolen goods, Secure transaction processing with inventory validation, Interactive dialogue system with contextual responses, Buy and sell interface with item filtering, Support for weapons, valuables, and illegal items, Anti-theft protection and transaction logging.</p>
  </a>
  <a href="./respawnpoints/" class="card">
    <h3>FOB Respawn</h3>
    <p>A comprehensive Forward Operating Base (FOB) respawn management system that allows administrators to place faction-specific respawn terminals. Players can respawn at designated FOB points based on their faction affiliation, with support for multiple spawn points per faction and map-specific configurations. The system includes client-server synchronization, administrative placement tools, and automatic respawn location selection.</p>
  </a>
  <a href="./handcuffs/" class="card">
    <h3>Handcuffs & Restraint</h3>
    <p>Comprehensive player restraint system featuring handcuff items and weapons, rope-based tying mechanics, complete weapon and movement restrictions for restrained players, drag functionality with submodule support, blindfold and gag features, lockpicking mechanics, realistic restraint sounds, and robust hostage scenario tools for immersive roleplay interactions.</p>
  </a>
  <a href="./food/" class="card">
    <h3>Hunger & Thirst</h3>
    <p>Comprehensive survival system that manages player hunger and thirst levels. Features dynamic food registration with customizable hunger/thirst values, stamina penalties for low hunger, automatic hunger degradation over time, and a variety of food items including canned goods, beverages, and MREs. Integrates with character factions and includes staff exemptions.</p>
  </a>
  <a href="./looting/" class="card">
    <h3>Interactive Looting</h3>
    <p>Lootable container system with two-panel UI. Containers generate flat item tables on chance roll. Players pick up or deposit items one at a time. Container resets timer when fully depleted.</p>
  </a>
  <a href="./recruiternpc/" class="card">
    <h3>Job Recruiter NPC</h3>
    <p>Automated job recruitment system that dynamically creates recruiter NPCs for all configured factions. Each NPC provides contextual dialog options allowing players to join jobs (with proper faction transfer hooks and loadout updates) or resign (reverting to default faction). Features intelligent option visibility based on player</p>
  </a>
  <a href="./keycards/" class="card">
    <h3>Keycards</h3>
    <p>Scanner and keycard access control built as a native Lilia module.</p>
  </a>
  <a href="./limbdamage/" class="card">
    <h3>Limb Damage</h3>
    <p>Advanced limb damage system that simulates realistic leg injuries. When players are shot in the legs (left or right leg hitgroups), they experience a temporary sprint disability with configurable duration. Features include automatic healing after the damage duration, visual HUD indicators with red screen effects and text warnings, server-side damage validation with blast damage immunity, toggleable system enable/disable functionality, and proper cleanup on player disconnection. The system uses networked variables for synchronized client-server state and provides immersive gameplay feedback through notifications and visual effects.</p>
  </a>
  <a href="./lscs/" class="card">
    <h3>LSCS Lightsaber</h3>
    <p>Integrates LSCS (Lightsaber Combat System) framework with Lilia, providing comprehensive lightsaber mechanics including customizable hilts, crystals, stances, and abilities. Features dual-wielding support, inventory management, and seamless character data synchronization for enhanced Jedi/Sith roleplay combat experience.</p>
  </a>
  <a href="./medical/" class="card">
    <h3>Medical & Wound</h3>
    <p>Comprehensive medical system featuring persistent wound tracking that reduces max health, a configurable medkit SWEP for healing self/others with cooldowns, and a surgery system requiring certified providers and surgical kits to treat lingering wounds. Players accumulate wounds on death that permanently decrease maximum health until treated through surgery.</p>
  </a>
  <a href="./marketplace/" class="card">
    <h3>Player Marketplace</h3>
    <p>A comprehensive player-to-player trading marketplace system featuring persistent database storage, configurable listing limits and pricing controls, intuitive GUI interfaces for buyers and sellers, administrative management tools with item removal and price modification capabilities, automatic economic transactions with money transfers, NPC vendor integration for marketplace access, real-time listing updates and search functionality, item validation and blacklist support, and robust server economy integration.</p>
  </a>
  <a href="./propbasedbuilding/" class="card">
    <h3>Prop-Based Building</h3>
    <p>Advanced prop-based construction system enabling players to craft and place diverse furniture items including chairs, tables, couches, storage units, and decorative props. Features resource requirements, health systems, destruction mechanics with specialized tools, and supports upgrades into functional entities for comprehensive base building and interior customization.</p>
  </a>
  <a href="./realtor/" class="card">
    <h3>Realtor - Property Management</h3>
    <p>Comprehensive property creation and management system featuring a specialized Property Creator weapon for intuitive door selection. Supports temporary rentals with daily pricing and permanent faction-owned properties with database persistence, preview positioning, and multi-door property compilation.</p>
  </a>
  <a href="./clearance/" class="card">
    <h3>Security Clearance</h3>
    <p>Implements a comprehensive security clearance level system that controls access to restricted areas through door permissions. Features include character-based clearance levels, administrative management tools, flag-based access control, and integration with the existing door system to enforce security restrictions based on player authorization levels.</p>
  </a>
  <a href="./robberies/" class="card">
    <h3>Store Robbery</h3>
    <p>Comprehensive store robbery system featuring interactive jewelry cases and cash registers with timed robbery mechanics. Players can steal various valuable items including cash bundles (0-500 value), jewelry bags (100-300 value), gold watches (50-150 value), and diamond rings (200-500 value) with weighted probability drops. The system includes police requirements (minimum 1-2 officers), configurable respawn timers (15-30 minutes), cooldown states, inventory management, and faction blacklist support. Features visual feedback with entity information display, action progress bars, and success/failure notifications.</p>
  </a>
  <a href="./taxi/" class="card">
    <h3>Taxi Transportation Service</h3>
    <p>A comprehensive taxi transportation system featuring an NPC dispatcher that spawns taxi vehicles for player hire, provides instant teleportation to predefined city locations with distance-based pricing, prevents duplicate taxi ownership, and integrates custom workshop vehicle models for realistic taxi services.</p>
  </a>
  <a href="./cellphones/" class="card">
    <h3>Telecommunications Network</h3>
    <p>Connects handheld phones and placed telephones through a shared network with direct dialing, ringing, answering, hangups, and live voice routing between both endpoint types.</p>
  </a>
  <a href="./terrorism/" class="card">
    <h3>Terrorism</h3>
    <p>Comprehensive terrorism system featuring vehicle car bombs that detonate on engine start and door breach explosives. Both bomb types support timed detonation (0-60 seconds) and remote detonation using handheld detonators. Includes realistic explosion physics with debris creation, player interaction menus for remote detonation, and a complete item system with explosive devices and detonators. Perfect for sabotage operations, controlled demolitions, and asymmetric warfare scenarios.</p>
  </a>
  <a href="./cardealer/" class="card">
    <h3>Vehicle Dealership</h3>
    <p>A comprehensive vehicle management system that provides NPC-based vehicle purchasing, ownership tracking, and maintenance services. Features include interactive dealer NPCs for vehicle sales with configurable pricing, vehicle return and repair systems with fee-based services, custom paint jobs and bodygroup modifications with individual pricing, secure garage storage for owned vehicles, full integration with popular driving addons, administrative privileges for staff vehicle access, and persistent vehicle ownership data across server restarts.</p>
  </a>
  <a href="./vehiclebeacons/" class="card">
    <h3>Vehicle Deployment Beacons</h3>
    <p>Faction-based in-world vehicle deployment beacons with ghost placement, secure validation, and support for Source and simfphys vehicle spawning.</p>
  </a>
  <a href="./caroptions/" class="card">
    <h3>Vehicle Entertainment & Passenger</h3>
    <p>Comprehensive vehicle enhancement system featuring CD player with music track management, album organization, and audio streaming for in-car entertainment. Includes passenger detection and management for both players and bots, supporting various vehicle types including LVS and SCars with proper seat identification and driver/passenger tracking.</p>
  </a>
</div>
